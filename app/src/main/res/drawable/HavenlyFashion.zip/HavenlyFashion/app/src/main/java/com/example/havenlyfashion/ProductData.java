package com.example.havenlyfashion;

import java.util.ArrayList;

public class ProductData {
    private static String [] productName = {

    };

    private static String [] productPrice = {

    };
    private static int [] productImage = {

    };


}
